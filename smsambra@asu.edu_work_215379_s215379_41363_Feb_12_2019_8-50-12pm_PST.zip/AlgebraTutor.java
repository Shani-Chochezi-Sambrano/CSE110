// Read the README File Carefully, then write your Algebra Tutor Program Here.

import java.util.Scanner;
import java.util.Random;

class Solve_for_Y_Method{
    public static void main(String [] args){
        	
        int count= 0;
        while (count <= 3){
        	Random rand = new Random(); 
        	int m = rand.nextInt(201)-100;
            int x = rand.nextInt(201)-100;
            int b = rand.nextInt(201)-100;
            int y = rand.nextInt(201)-100;
            
            menu(m, x, b, y);
        	
            int number_of_questions= 0;
		    int correct_answers = 0;
		    int score = (correct_answers/number_of_questions); 
            
                   
        	Scanner user_input = new Scanner(System.in);
             System.out.println(" Your current score is " + score);
             
             System.out.println(" Good practice. Want more? (yes or no?)");
             String user_response = user_input.nextLine();
             count = count + 1;   
             if(user_response.equals("yes")){
            	 count = 0;
            }else{
             System.out.println("Thanks for practicing.");
            break;
            }   
        
        
            }      
   
   
    }
    
        public static int find_y(int m, int x, int b){
        int y = (int)(m * x + b);
        return y;
        }
   
    public static void menu(int m, int x, int b, int y){
        Scanner user_input2 = new Scanner(System.in);  
        String name = " ";
        System.out.println("Consider the Slope Intercept Form y = mx + b.");
        System.out.println(" Select 1 to solve for y, 2 to solve for m, 3 to solve for b, and 4 to quit:" );
        int selection;
        selection = user_input2.nextInt();
        if(selection == 1){
        go_to_menu_selection_1(m, x, b);
        }else if (selection == 2){
        go_to_menu_selection_2(y, x, b);
        }else if (selection == 3){
        go_to_menu_selection_3(m, x, y);
        }else if (selection == 4){
        
        }
        
        
    }
        
    public static int go_to_menu_selection_1(int m, int x, int b){
        int score = 0;
    	Scanner user_input = new Scanner(System.in);
        String name = " ";  
        System.out.println("Given m = " + m);
        System.out.println("x = " + x);
        System.out.println("b = " + b);
        System.out.print("What is the value of y? ");
        int y_value = find_y(m, x, b);
        int number;
        number = user_input.nextInt();
        if (number == y_value){
        	score = 1;
          System.out.println("Thank you for your answer. That is correct");
        }else{
          System.out.println("Good try; however, that is incorrect. The answer is " + y_value);
        }
        
        int count_2= 0;
        while (count_2 >3 && number != y_value) 
         {
        System.out.println("To isolate a variable, look at the operation happening with the other variable(s).");
        System.out.println("Then insert the opposite operation on both sides of the equation.");
        count_2 = count_2 +1;
        }
        
        
        return score;
        
    }
                
    public static int go_to_menu_selection_2(int y, int x, int b){
        int score = 0;
    	Scanner user_input = new Scanner(System.in);
        String name = " ";  
        System.out.println("Given y = " + y);
        System.out.println("x = " + x);
        System.out.println("b = " + b);
        System.out.print("What is the value of m? ");
        int number = user_input.nextInt();
        int m_value = find_m(y, x, b);
        if (number == m_value){
        	score = 1;
          System.out.println("Thank you for your answer. That is correct");
        }else{
          System.out.println("Good try; however, that is incorrect. The answer is " + m_value);
        }
        
        int count_2= 0;
        while (count_2 >3 && number != m_value) 
         {
        System.out.println("To isolate a variable, look at the operation happening with the other variable(s).");
        System.out.println("Then insert the opposite operation on both sides of the equation.");
        count_2 = count_2 +1;
        }
        
        
        return score;
    }
    public static int find_m(int x, int b, int y){
        int m = (int) (y-b)/x;
        return m;
        }        

    
    public static int go_to_menu_selection_3(int m, int x, int y){
        int score = 0;
    	Scanner user_input = new Scanner(System.in);
        String name = " ";  
        System.out.println("Given m = " + m);
        System.out.println("x = " + x);
        System.out.println("y = " + y);
        System.out.print("What is the value of b? ");
        int b_value = find_b(m, x, y);
        int number = user_input.nextInt();
        if (number==b_value){
        	score = 1;
          System.out.println("Thank you for your answer. That is correct");
        }else{
          System.out.println("Good try; however, that is incorrect. The answer is " + b_value);
        }
        
        int count_2= 0;
        while (count_2 >3 && number != b_value) 
         {
        System.out.println("To isolate a variable, look at the operation happening with the other variable(s).");
        System.out.println("Then insert the opposite operation on both sides of the equation.");
        count_2 = count_2 +1;
        }
        
    return score;
    
    }

    public static int find_b(int m, int x, int y){
          int b = (int)((y)/(m * x));
          return b;
        }
                    
}




















